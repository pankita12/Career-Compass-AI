
import streamlit as st

st.set_page_config(page_title="Career Compass AI", layout="centered")

st.title("🎯 Career Compass AI")
st.write("Welcome! This app helps you discover the best career paths based on your interests and skills.")

# Form-style input
with st.form("career_form"):
    subjects = st.multiselect("Which subjects do you enjoy?", ["Math", "Science", "Art", "Business", "Technology"])
    skills = st.multiselect("Select your top 3 skills:", ["Logical Thinking", "Creativity", "Communication", "Leadership", "Problem Solving"])
    preference = st.radio("Do you prefer working with:", ["People", "Data", "Machines"])
    teamwork = st.radio("Do you like working in teams or solo?", ["Teamwork", "Solo"])
    education = st.selectbox("Your highest level of education:", ["High School", "Undergraduate", "Postgraduate"])
    goal = st.radio("What matters most in your career?", ["High Salary", "Flexibility", "Job Security"])
    submitted = st.form_submit_button("Get Career Suggestions")

if submitted:
    st.subheader("🔍 Suggested Careers:")
    st.write("1. Business Analyst (Confidence: 91%)")
    st.write("2. Marketing Manager (Confidence: 86%)")
    st.write("3. HR Manager (Confidence: 81%)")
    st.success("These suggestions are based on your selected preferences.")
