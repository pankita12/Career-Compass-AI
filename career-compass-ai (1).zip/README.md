# Career Compass AI

A simple AI-based career recommendation tool built with Streamlit.